from notificacoes import NotificadorEmail, NotificadorSMS, NotificadorApp, CentralNotificacoes

central = CentralNotificacoes()

central.adicionar_notificador(NotificadorEmail())
central.adicionar_notificador(NotificadorSMS())
central.adicionar_notificador(NotificadorApp())

central.enviar_para_todos("Sua conta foi atualizada com sucesso!")
