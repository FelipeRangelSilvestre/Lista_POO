from midias import Video, Podcast, TextoNarrado, Plataforma

plataforma = Plataforma("EduLearn")

plataforma.adicionar_midia(Video("Introdução ao Python", 45, "1080p"))
plataforma.adicionar_midia(Podcast("Tech Talks #10", 60, "Ana Lima"))
plataforma.adicionar_midia(TextoNarrado("O Pequeno Príncipe", 120, "Português"))

plataforma.listar_midias()
plataforma.reproduzir_todas()
