from abc import ABC, abstractmethod


class Midia(ABC):
    def __init__(self, titulo, duracao):
        self.titulo = titulo
        self.duracao = duracao

    def mostrar_info(self):
        print(f"Título: {self.titulo} | Duração: {self.duracao} min")

    @abstractmethod
    def reproduzir(self):
        pass


class Video(Midia):
    def __init__(self, titulo, duracao, resolucao):
        super().__init__(titulo, duracao)
        self.resolucao = resolucao

    def reproduzir(self):
        print(f"[Vídeo] Reproduzindo '{self.titulo}' em {self.resolucao}")


class Podcast(Midia):
    def __init__(self, titulo, duracao, apresentador):
        super().__init__(titulo, duracao)
        self.apresentador = apresentador

    def reproduzir(self):
        print(f"[Podcast] Reproduzindo '{self.titulo}' com {self.apresentador}")


class TextoNarrado(Midia):
    def __init__(self, titulo, duracao, idioma):
        super().__init__(titulo, duracao)
        self.idioma = idioma

    def reproduzir(self):
        print(f"[Texto Narrado] Reproduzindo '{self.titulo}' em {self.idioma}")


class Plataforma:
    def __init__(self, nome):
        self.nome = nome
        self.midias = []

    def adicionar_midia(self, midia):
        self.midias.append(midia)

    def listar_midias(self):
        print(f"\n--- Mídias da plataforma '{self.nome}' ---")
        for m in self.midias:
            m.mostrar_info()

    def reproduzir_todas(self):
        print(f"\n--- Reproduzindo todas as mídias ---")
        for m in self.midias:
            m.reproduzir()
