from abc import ABC, abstractmethod
from typing import Protocol


# Parte A - ABC
class Armazenador(ABC):
    @abstractmethod
    def salvar(self, dado):
        pass


class ArmazenadorArquivo(Armazenador):
    def salvar(self, dado):
        print(f"[Arquivo] Salvando: '{dado}'")


class ArmazenadorBanco(Armazenador):
    def salvar(self, dado):
        print(f"[Banco de Dados] Salvando: '{dado}'")


# Parte B - Protocol
class Salvavel(Protocol):
    def salvar(self, dado) -> None:
        ...


class ArmazenadorNuvem:
    def salvar(self, dado):
        print(f"[Nuvem] Salvando: '{dado}'")


# Parte C - Funções
def executar_salvamento_formal(armazenador: Armazenador, dado):
    armazenador.salvar(dado)


def executar_salvamento_flexivel(objeto: Salvavel, dado):
    objeto.salvar(dado)
