from funcionarios import FuncionarioAssalariado, FuncionarioHorista, FuncionarioComissionado, Empresa

empresa = Empresa("TechAmazon")

empresa.adicionar_funcionario(FuncionarioAssalariado("Carlos", "111.111.111-11", 5000.00))
empresa.adicionar_funcionario(FuncionarioHorista("Mariana", "222.222.222-22", 160, 25.00))
empresa.adicionar_funcionario(FuncionarioComissionado("Lucas", "333.333.333-33", 20000.00, 10))

empresa.listar_funcionarios()
empresa.mostrar_folha_pagamento()
