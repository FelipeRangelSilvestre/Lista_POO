# Lista de Exercícios II - Parte 1
**Disciplina:** Engenharia de Software e Sistemas de Informação  
**Prof.:** Alternei Brito - UFAM/ICET

## Requisitos
- Python 3.8+

## Como executar cada questão

```bash
# Questão 1 - Sistema de Mídias Educacionais
cd q1 && python main.py

# Questão 2 - Sistema de Funcionários
cd q2 && python main.py

# Questão 3 - Sistema de Notificações com ABC
cd q3 && python main.py

# Questão 4 - Sistema de Impressão com Protocol
cd q4 && python main.py

# Questão 5 - Sistema de Armazenamento com ABC e Protocol
cd q5 && python main.py
```

## Descrição das questões

| Questão | Tema | Conceitos |
|---------|------|-----------|
| Q1 | Mídias Educacionais | ABC, herança, polimorfismo |
| Q2 | Funcionários de Empresa | ABC, herança, polimorfismo |
| Q3 | Sistema de Notificações | ABC, herança, polimorfismo |
| Q4 | Sistema de Impressão | Protocol, duck typing |
| Q5 | Sistema de Armazenamento | ABC + Protocol (comparação) |
